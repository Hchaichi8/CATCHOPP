# Guide de Test - Commentaires et Réactions

## Tests Backend (Spring Boot)

### 1. Démarrer l'application
```bash
cd CatchOPP/CommunityMicroService
./mvnw spring-boot:run
```

### 2. Tester les APIs avec curl/Postman

#### Créer un post (prérequis)
```bash
curl -X POST http://localhost:8080/api/posts \
  -H "Content-Type: application/json" \
  -d '{
    "content": "Ceci est un post de test pour les commentaires et réactions",
    "authorId": 1,
    "isAnnouncement": false
  }'
```

#### Ajouter des réactions
```bash
# Réaction Like
curl -X POST http://localhost:8080/api/reactions \
  -H "Content-Type: application/json" \
  -d '{
    "postId": 1,
    "authorId": 1,
    "type": "LIKE"
  }'

# Réaction Love
curl -X POST http://localhost:8080/api/reactions \
  -H "Content-Type: application/json" \
  -d '{
    "postId": 1,
    "authorId": 2,
    "type": "LOVE"
  }'

# Réaction Happy
curl -X POST http://localhost:8080/api/reactions \
  -H "Content-Type: application/json" \
  -d '{
    "postId": 1,
    "authorId": 3,
    "type": "HAPPY"
  }'
```

#### Récupérer les compteurs de réactions
```bash
curl http://localhost:8080/api/reactions/post/1/counts
```

Réponse attendue :
```json
{
  "LIKE": 1,
  "LOVE": 1,
  "HAPPY": 1,
  "SAD": 0,
  "ANGRY": 0,
  "WOW": 0
}
```

#### Ajouter des commentaires
```bash
# Commentaire 1
curl -X POST http://localhost:8080/api/comments \
  -H "Content-Type: application/json" \
  -d '{
    "postId": 1,
    "authorId": 1,
    "content": "Super post ! Merci pour le partage 👍"
  }'

# Commentaire 2
curl -X POST http://localhost:8080/api/comments \
  -H "Content-Type: application/json" \
  -d '{
    "postId": 1,
    "authorId": 2,
    "content": "Très intéressant, j'\''ai hâte de voir la suite !"
  }'
```

#### Récupérer les commentaires
```bash
curl http://localhost:8080/api/comments/post/1
```

#### Compter les commentaires
```bash
curl http://localhost:8080/api/comments/post/1/count
```

#### Récupérer un post avec toutes ses interactions
```bash
curl http://localhost:8080/api/posts/1
```

## Tests Frontend (Angular)

### 1. Démarrer l'application Angular
```bash
cd FrontFreelanceApp
npm install
ng serve
```

### 2. Navigation vers le dashboard
1. Ouvrir http://localhost:4200
2. Naviguer vers le Club Dashboard
3. Aller dans la section "Announcements" > "Community Posts"

### 3. Tests d'interaction

#### Test des Réactions
1. **Cliquer sur le bouton Like** : Devrait ajouter une réaction LIKE
2. **Cliquer sur le bouton "+"** : Devrait ouvrir le sélecteur d'emojis
3. **Sélectionner différents emojis** : Love ❤️, Happy 😊, Sad 😢, etc.
4. **Re-cliquer sur la même réaction** : Devrait la supprimer (toggle)
5. **Vérifier les compteurs** : Doivent se mettre à jour en temps réel

#### Test des Commentaires
1. **Cliquer sur "X Comments"** : Devrait ouvrir/fermer la section commentaires
2. **Écrire un commentaire** : Dans la textarea
3. **Appuyer sur Entrée ou "Post"** : Devrait ajouter le commentaire
4. **Voir le commentaire apparaître** : Avec nom d'auteur et timestamp
5. **Tester l'édition** : Cliquer "Edit" sur son propre commentaire
6. **Tester la suppression** : Cliquer "Delete" avec confirmation

## Scénarios de Test Complets

### Scénario 1 : Engagement Multiple
1. Utilisateur A ajoute une réaction LIKE
2. Utilisateur B ajoute une réaction LOVE
3. Utilisateur C ajoute un commentaire
4. Utilisateur A répond avec un autre commentaire
5. Utilisateur B change sa réaction de LOVE à HAPPY
6. Vérifier que tous les compteurs sont corrects

### Scénario 2 : Gestion des Erreurs
1. Essayer d'ajouter un commentaire vide
2. Essayer de modifier le commentaire d'un autre utilisateur
3. Tester avec un postId inexistant
4. Vérifier les messages d'erreur appropriés

### Scénario 3 : Performance
1. Ajouter 50+ commentaires sur un post
2. Ajouter des réactions de 20+ utilisateurs différents
3. Vérifier que l'interface reste responsive
4. Tester le scroll dans la liste des commentaires

## Données de Test Recommandées

### Posts de Test
```sql
INSERT INTO posts (content, author_id, is_announcement, created_at) VALUES
('🎉 Bienvenue dans notre nouvelle communauté ! Partagez vos idées et connectez-vous avec d''autres membres.', 1, true, NOW()),
('Quelqu''un a-t-il des recommandations pour apprendre Angular ? Je débute et cherche de bonnes ressources.', 2, false, NOW()),
('Superbe événement hier soir ! Merci à tous ceux qui ont participé. Voici quelques photos...', 3, false, NOW()),
('💡 Astuce du jour : Utilisez les raccourcis clavier pour être plus productif. Quels sont vos favoris ?', 1, false, NOW()),
('🚀 Notre projet open source vient d''atteindre 1000 stars sur GitHub ! Merci à la communauté !', 4, false, NOW());
```

### Utilisateurs de Test
```sql
INSERT INTO users (id, name, email) VALUES
(1, 'Alice Martin', 'alice@example.com'),
(2, 'Bob Dupont', 'bob@example.com'),
(3, 'Claire Moreau', 'claire@example.com'),
(4, 'David Bernard', 'david@example.com'),
(5, 'Emma Petit', 'emma@example.com');
```

## Vérifications de Qualité

### Checklist Frontend
- [ ] Les emojis s'affichent correctement sur tous les navigateurs
- [ ] L'interface est responsive (mobile/desktop)
- [ ] Les animations sont fluides
- [ ] Les compteurs se mettent à jour sans rechargement
- [ ] La gestion d'erreurs fonctionne
- [ ] L'accessibilité est respectée (ARIA labels)

### Checklist Backend
- [ ] Les contraintes de base de données fonctionnent
- [ ] Les validations côté serveur sont effectives
- [ ] Les réponses JSON sont bien formatées
- [ ] Les erreurs HTTP sont appropriées (400, 404, 500)
- [ ] Les performances sont acceptables avec beaucoup de données
- [ ] La sécurité est assurée (pas d'injection SQL)

## Métriques de Performance

### Temps de Réponse Attendus
- Ajouter une réaction : < 200ms
- Ajouter un commentaire : < 300ms
- Charger les commentaires : < 500ms
- Charger les compteurs : < 100ms

### Limites Recommandées
- Max 1000 commentaires par post (avec pagination)
- Max 10 réactions par utilisateur par minute (rate limiting)
- Max 500 caractères par commentaire
- Cache des compteurs pendant 30 secondes

Ce guide vous permettra de tester complètement le système de commentaires et réactions implémenté.