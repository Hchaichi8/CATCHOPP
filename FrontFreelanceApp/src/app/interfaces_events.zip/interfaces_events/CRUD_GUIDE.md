# Guide CRUD - Groups, Clubs & Events Dashboard

## Vue d'ensemble

Le dashboard des clubs et groupes offre maintenant des fonctionnalités CRUD complètes pour gérer les groupes, les clubs et les événements.

## Fonctionnalités

### 1. Gestion des Groupes (Groups)

#### Créer un groupe
- Cliquez sur le bouton "+ New group" dans la section "Groups"
- Remplissez le formulaire:
  - **Nom du groupe** (requis)
  - **Description** (requis)
  - **Type de groupe** (requis): PUBLIC, PRIVATE, ou INVITE_ONLY
  - **URL de la bannière** (optionnel)
- Cliquez sur "Create" pour sauvegarder

#### Modifier un groupe
- Cliquez sur l'icône d'édition (crayon) à côté du groupe
- Modifiez les informations dans le formulaire
- Cliquez sur "Update" pour sauvegarder les modifications

#### Supprimer un groupe
- Cliquez sur l'icône de suppression (poubelle) à côté du groupe
- Confirmez la suppression dans la boîte de dialogue
- Le groupe sera supprimé de la base de données

#### Afficher les groupes
- Tous les groupes sont affichés dans la section "Groups"
- Chaque carte de groupe affiche:
  - Nom du groupe
  - Description
  - Type (PUBLIC/PRIVATE/INVITE_ONLY)
  - Badge de statut "Active"
  - Boutons d'action (éditer/supprimer)

### 2. Gestion des Clubs (Specialized Clubs)

#### Créer un club
- Cliquez sur le bouton "+ New club" dans la section "Specialized clubs"
- Remplissez le formulaire:
  - **Nom du club** (requis)
  - **Description** (requis)
  - **Intérêts** (optionnel): Liste séparée par des virgules (ex: Technology, Design, Business)
  - **URL de la bannière** (optionnel)
- Cliquez sur "Create" pour sauvegarder

#### Modifier un club
- Cliquez sur l'icône d'édition (crayon) à côté du club
- Modifiez les informations dans le formulaire
- Cliquez sur "Update" pour sauvegarder les modifications

#### Supprimer un club
- Cliquez sur l'icône de suppression (poubelle) à côté du club
- Confirmez la suppression dans la boîte de dialogue
- Le club sera supprimé de la base de données

#### Afficher les clubs
- Tous les clubs sont affichés dans la section "Specialized clubs"
- Chaque carte de club affiche:
  - Nom du club
  - Description
  - Tags d'intérêts (jusqu'à 2 affichés)
  - Badge de statut "Active"
  - Boutons d'action (éditer/supprimer)

### 3. Gestion des Événements (Events)

#### Créer un événement
- Cliquez sur le bouton "+ New event" dans la section "All Events" ou "Upcoming events"
- Remplissez le formulaire:
  - **Titre de l'événement** (requis)
  - **Description** (requis)
  - **Date et heure de début** (requis)
  - **Date et heure de fin** (requis)
  - **Lieu** (requis): Adresse physique ou "Online"
  - **Groupe associé** (optionnel): Sélectionnez un groupe existant
- Cliquez sur "Create" pour sauvegarder
- **Important**: Les événements sont automatiquement approuvés (status: APPROVED)

#### Modifier un événement
- Cliquez sur l'icône d'édition (crayon) à côté de l'événement
- Modifiez les informations dans le formulaire
- Cliquez sur "Update" pour sauvegarder les modifications

#### Supprimer un événement
- Cliquez sur l'icône de suppression (poubelle) à côté de l'événement
- Confirmez la suppression dans la boîte de dialogue
- L'événement sera supprimé de la base de données

#### Afficher les événements
Les événements sont affichés dans deux sections:

**Section "All Events"** (Colonne de gauche):
- Affiche TOUS les événements (passés et futurs)
- Triés par date de début (chronologique)
- Chaque carte d'événement affiche:
  - Badge de date (jour et mois)
  - Titre de l'événement
  - Description complète
  - Lieu
  - Date et heure de début
  - Groupe associé (si applicable)
  - Boutons d'action (éditer/supprimer)

**Section "Upcoming Events"** (Colonne de droite):
- Affiche uniquement les 5 prochains événements à venir
- Triés par date (les plus proches en premier)
- Format compact avec informations essentielles
- Boutons d'action inline (éditer/supprimer)

## Architecture Technique

### Services utilisés

#### GroupService
```typescript
- getAllGroups(): Observable<Group[]>
- getGroupById(id: number): Observable<Group>
- createGroup(group: Group): Observable<Group>
- updateGroup(id: number, group: Group): Observable<Group>
- deleteGroup(id: number): Observable<void>
```

#### ClubService
```typescript
- getAllClubs(): Observable<Club[]>
- getClubById(id: number): Observable<Club>
- createClub(club: Club): Observable<Club>
- updateClub(id: number, club: Club): Observable<Club>
- deleteClub(id: number): Observable<void>
- searchClubsByInterest(interest: string): Observable<Club[]>
```

#### EventService
```typescript
- getAllEvents(): Observable<EventItem[]>
- getEventById(id: number): Observable<EventItem>
- getEventsByGroupId(groupId: number): Observable<EventItem[]>
- createEvent(event: EventItem): Observable<EventItem>
- updateEvent(id: number, event: EventItem): Observable<EventItem>
- deleteEvent(id: number): Observable<void>
- getPendingEvents(): Observable<EventItem[]>
- approveEvent(id: number): Observable<EventItem>
- rejectEvent(id: number): Observable<EventItem>
```

### Endpoints API

#### Groups
- `POST /api/groups` - Créer un groupe
- `GET /api/groups` - Récupérer tous les groupes
- `GET /api/groups/{id}` - Récupérer un groupe par ID
- `PUT /api/groups/{id}` - Mettre à jour un groupe
- `DELETE /api/groups/{id}` - Supprimer un groupe

#### Clubs
- `POST /api/clubs` - Créer un club
- `GET /api/clubs` - Récupérer tous les clubs
- `GET /api/clubs/{id}` - Récupérer un club par ID
- `PUT /api/clubs/{id}` - Mettre à jour un club
- `DELETE /api/clubs/{id}` - Supprimer un club
- `GET /api/clubs/search?interest={interest}` - Rechercher des clubs par intérêt

#### Events
- `POST /api/events` - Créer un événement
- `GET /api/events` - Récupérer tous les événements
- `GET /api/events/{id}` - Récupérer un événement par ID
- `GET /api/events/group/{groupId}` - Récupérer les événements d'un groupe
- `PUT /api/events/{id}` - Mettre à jour un événement
- `DELETE /api/events/{id}` - Supprimer un événement

## Modèles de données

### Group
```typescript
interface Group {
  id?: number;
  name: string;
  description: string;
  bannerUrl?: string;
  type: 'PUBLIC' | 'PRIVATE' | 'INVITE_ONLY';
}
```

### Club
```typescript
interface Club {
  id?: number;
  name: string;
  description: string;
  bannerUrl?: string;
  interests?: string;
  creatorId?: number;
  createdAt?: string;
}
```

### Event
```typescript
interface EventItem {
  id?: number;
  title: string;
  description: string;
  location: string;
  startDate: string; // ISO 8601 format
  endDate: string;   // ISO 8601 format
  group?: { id: number };
  creatorId?: number;
  createdAt?: string;
  status?: string; // PENDING, APPROVED, REJECTED
}
```

## Validation des formulaires

### Champs requis
- **Groups**: name, description, type
- **Clubs**: name, description
- **Events**: title, description, location, startDate, endDate

### Champs optionnels
- **Groups**: bannerUrl
- **Clubs**: interests, bannerUrl
- **Events**: group (association à un groupe)

### Validations spéciales
- **Events**: La date de fin doit être postérieure à la date de début
- **Events**: Les dates sont au format datetime-local (YYYY-MM-DDTHH:mm)

## Gestion des erreurs

Le système affiche des alertes pour:
- Succès de création/modification/suppression
- Erreurs de validation (champs requis manquants, dates invalides)
- Erreurs de communication avec l'API

## Statistiques

Le dashboard affiche en temps réel:
- **Active groups**: Nombre total de groupes
- **Total Clubs**: Nombre total de clubs
- **Events this month**: Nombre d'événements du mois en cours

Les statistiques sont automatiquement mises à jour après chaque opération CRUD.

## Fonctionnalités spéciales

### Événements à venir
- Affichage automatique des 5 prochains événements
- Tri chronologique (du plus proche au plus éloigné)
- Filtrage automatique (seuls les événements futurs sont affichés)
- Mise à jour en temps réel après création/modification/suppression

### Tous les événements
- Section dédiée "All Events" affichant tous les événements
- Tri chronologique par date de début
- Affichage complet avec toutes les informations
- Cartes interactives avec hover effects
- Actions rapides (éditer/supprimer) sur chaque carte

### Statut automatique
- **Tous les événements créés sont automatiquement approuvés**
- Status: APPROVED par défaut
- Pas de workflow de validation (pending/approved)
- Affichage immédiat après création

### Association groupe-événement
- Possibilité d'associer un événement à un groupe existant
- Liste déroulante des groupes disponibles
- Option "No group" pour les événements indépendants

## Interface utilisateur

### Modales
- Design moderne avec overlay semi-transparent
- Animation d'apparition fluide
- Formulaires clairs et intuitifs
- Boutons d'action bien visibles
- Fermeture possible en cliquant en dehors de la modale
- Support des champs datetime-local pour les événements

### Cartes de groupes/clubs/événements
- Design épuré avec informations essentielles
- Badges de statut colorés
- Boutons d'action avec icônes
- Hover effects pour meilleure UX
- Badge de date visuel pour les événements

## Responsive Design

L'interface s'adapte automatiquement aux différentes tailles d'écran:
- Desktop: Layout en colonnes avec sidebar
- Tablet: Layout adapté
- Mobile: Layout en colonne unique avec modales plein écran

## Prochaines améliorations possibles

1. Recherche et filtrage des groupes/clubs/événements
2. Pagination pour grandes listes
3. Upload d'images pour les bannières
4. Gestion des membres de groupes
5. Statistiques détaillées par groupe/club/événement
6. Export de données (CSV, PDF)
7. Notifications en temps réel
8. Drag & drop pour réorganiser
9. Calendrier visuel pour les événements
10. Gestion des participants aux événements
11. Rappels automatiques pour les événements
12. Filtrage par statut d'événement (PENDING, APPROVED, REJECTED)
13. Vue carte pour les événements avec localisation
14. Intégration avec calendriers externes (Google Calendar, Outlook)

## Exemples d'utilisation

### Créer un événement associé à un groupe
1. Assurez-vous d'avoir créé au moins un groupe
2. Cliquez sur "+ New event"
3. Remplissez les informations de l'événement
4. Sélectionnez le groupe dans la liste déroulante
5. Cliquez sur "Create"

### Modifier un événement existant
1. Trouvez l'événement dans la liste "Upcoming events"
2. Cliquez sur l'icône d'édition (crayon)
3. Modifiez les informations souhaitées
4. Cliquez sur "Update"

### Supprimer un événement
1. Trouvez l'événement dans la liste
2. Cliquez sur l'icône de suppression (poubelle)
3. Confirmez la suppression

## Notes techniques

### Format des dates
- Les dates sont stockées au format ISO 8601 dans la base de données
- L'interface utilise le type `datetime-local` pour une meilleure UX
- Conversion automatique entre les formats lors de la sauvegarde/chargement

### Tri des événements
- Les événements à venir sont automatiquement triés par date de début
- Section "All Events": Tous les événements triés chronologiquement
- Section "Upcoming Events": Seuls les événements futurs (max 5)
- Mise à jour automatique du tri après chaque modification

### Statut des événements
- **Tous les événements sont automatiquement approuvés (APPROVED)**
- Pas de workflow de validation
- Pas de statut PENDING
- Affichage immédiat dans les deux sections

### Performance
- Chargement asynchrone des données
- Mise à jour optimisée des listes après modifications
- Gestion d'erreur robuste avec fallback sur données mock
