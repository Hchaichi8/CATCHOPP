# Dépannage des Posts - Guide Étape par Étape

## Problème Identifié
Les posts sont créés et stockés dans la base de données mais ne s'affichent pas dans l'interface utilisateur.

## Étapes de Diagnostic

### 1. Vérifier le Backend

#### A. Redémarrer le serveur Spring Boot
```bash
cd CatchOPP/CommunityMicroService
./mvnw spring-boot:run
```

#### B. Tester les APIs avec curl

**Vérifier tous les posts :**
```bash
curl http://localhost:8089/api/posts/debug/all
```

**Vérifier les posts d'un groupe :**
```bash
curl http://localhost:8089/api/posts/debug/group/1
```

**Tester l'API simple :**
```bash
curl http://localhost:8089/api/posts/group/1/simple
```

**Créer un post de test :**
```bash
curl -X POST http://localhost:8089/api/posts \
  -H "Content-Type: application/json" \
  -d '{
    "group": {"id": 1},
    "authorId": 1,
    "content": "Test post from curl",
    "isAnnouncement": false
  }'
```

### 2. Vérifier la Base de Données

Dans phpMyAdmin :
1. Ouvrir la table `posts`
2. Vérifier que les posts ont bien un `group_id` renseigné
3. Vérifier que le `group_id` correspond à un groupe existant dans la table `groups`

### 3. Vérifier le Frontend

#### A. Ouvrir les DevTools du navigateur
1. F12 ou clic droit > Inspecter
2. Aller dans l'onglet Console
3. Aller dans l'onglet Network

#### B. Naviguer vers la page de groupe
```
http://localhost:4200/groups/1
```

#### C. Vérifier les logs dans la console
Rechercher ces messages :
```
Loading posts for group: 1
Received simple posts: [...]
Mapped simple posts: [...]
```

#### D. Vérifier les requêtes HTTP dans Network
1. Filtrer par XHR
2. Chercher les requêtes vers `/api/posts/group/1/simple`
3. Vérifier la réponse

### 4. Tests Spécifiques

#### A. Test de Création de Post
1. Aller sur `/groups/1`
2. Écrire un message dans le textarea
3. Cliquer sur "Post"
4. Vérifier les logs console :
   ```
   Creating post: {group: {id: 1}, authorId: 1, content: "...", isAnnouncement: false}
   Post created successfully: {...}
   Loading posts for group: 1
   ```

#### B. Test Direct de l'API
Ouvrir la console du navigateur et exécuter :
```javascript
fetch('http://localhost:8089/api/posts/group/1/simple')
  .then(r => r.json())
  .then(data => console.log('Direct API test:', data));
```

## Solutions Possibles

### Solution 1 : Problème de Repository
Si l'API ne retourne aucun post, le problème vient de la requête JPA.

**Action :** Modifier le PostRepository pour utiliser la méthode alternative :
```java
List<Post> findByGroup_IdOrderByCreatedAtDesc(Long groupId);
```

### Solution 2 : Problème de CORS
Si les requêtes sont bloquées par CORS.

**Action :** Vérifier que `@CrossOrigin(origins = "*")` est présent sur le contrôleur.

### Solution 3 : Problème de Port
Si le backend n'est pas sur le bon port.

**Action :** Vérifier que l'API_CONFIG utilise le bon port (8089).

### Solution 4 : Problème de Mapping
Si les posts sont retournés mais mal mappés dans le frontend.

**Action :** Vérifier les logs de mapping dans la console.

## Actions Correctives Appliquées

### Backend
1. ✅ Ajout de logs de debug dans PostService
2. ✅ Ajout d'endpoints de debug (`/debug/all`, `/debug/group/{id}`)
3. ✅ Ajout d'API simple (`/group/{id}/simple`)
4. ✅ Amélioration du PostRepository avec requête JPQL

### Frontend
1. ✅ Ajout de logs de debug dans loadGroupPosts()
2. ✅ Ajout de logs dans createPost()
3. ✅ Ajout d'API simple dans PostService
4. ✅ Système de fallback en cascade (simple → enrichie → ancienne)

## Prochaines Étapes

1. **Redémarrer le backend** avec les nouveaux logs
2. **Rafraîchir le frontend** 
3. **Tester la création d'un post** et vérifier les logs
4. **Vérifier les APIs** avec curl si nécessaire
5. **Analyser les logs** pour identifier le point de défaillance

## Résultats Attendus

Après ces corrections, vous devriez voir :
- ✅ Posts créés avec `group_id` correct dans la DB
- ✅ APIs backend retournant les posts
- ✅ Frontend affichant les posts dans l'interface
- ✅ Logs détaillés pour le debugging

Si le problème persiste, les logs nous indiqueront exactement où ça bloque.