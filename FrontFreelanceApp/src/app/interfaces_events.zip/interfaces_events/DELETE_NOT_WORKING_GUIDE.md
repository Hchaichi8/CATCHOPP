# Guide: Le Bouton Delete Ne Fonctionne Pas

## Symptômes
- Vous cliquez sur le bouton "Delete" dans l'admin dashboard
- Une erreur apparaît: "Failed to delete group. Please try again."
- Le groupe n'est pas supprimé

## Cause Principale
Le backend n'a pas été redémarré avec les nouvelles corrections de code.

## Solution Rapide ⚡

### Étape 1: Redémarrer le Backend
Vous devez redémarrer le serveur Spring Boot. Voici comment:

**Option A: Depuis votre IDE (Recommandé)**
- IntelliJ IDEA: Cliquez sur le bouton "Restart" (icône verte)
- Eclipse: Run As → Spring Boot App
- VS Code: Appuyez sur F5

**Option B: Depuis le Terminal**
```powershell
# Arrêter le backend actuel
Get-Process -Name "java" | Stop-Process -Force

# Redémarrer (depuis le dossier CommunityMicroService)
.\mvnw.cmd spring-boot:run
```

### Étape 2: Vérifier que le Backend a Redémarré
Ouvrez votre navigateur et allez sur:
```
http://localhost:8089/api/groups
```

Vous devriez voir la liste des groupes en JSON.

### Étape 3: Tester la Suppression
1. Allez sur http://localhost:4200/admin
2. Cliquez sur "Delete" sur un groupe de test
3. Confirmez la suppression
4. ✅ Le groupe devrait être supprimé avec succès!

## Vérifications Supplémentaires

### 1. Le Frontend est-il à jour?
Le frontend devrait se recompiler automatiquement. Vérifiez dans le terminal Angular:
```
✔ Compiled successfully
```

### 2. La Base de Données est-elle Accessible?
Vérifiez que MySQL/MariaDB tourne et que la base `catchopp_project_db` existe.

### 3. Les Logs du Backend
Quand vous supprimez un groupe, vous devriez voir dans les logs:
```
Starting deletion of group 2
Deleting posts for group 2
Deleting events for group 2
Deleting members for group 2
Deleting group 2
Group 2 deleted successfully
```

## Corrections Appliquées au Code

### Backend (Java)
✅ **GroupMemberRepository.java** - Ajout de @Modifying et @Transactional
✅ **PostRepository.java** - Méthode deleteByGroupId ajoutée
✅ **EventRepository.java** - Méthode deleteByGroupId ajoutée
✅ **GroupService.java** - Suppression en cascade correcte
✅ **GroupController.java** - Meilleure gestion des erreurs

### Frontend (Angular)
✅ **admin-dashboard.component.ts** - Message de confirmation amélioré
✅ **club-dashboard.component.ts** - Correction des erreurs NG0100

## Test Manuel de l'API

Vous pouvez tester directement l'API avec PowerShell:

```powershell
# Créer un groupe de test
$body = @{
    name = "Test Delete"
    description = "Groupe de test"
    type = "PUBLIC"
} | ConvertTo-Json

$newGroup = (Invoke-WebRequest -Uri "http://localhost:8089/api/groups" -Method POST -Body $body -ContentType "application/json" -UseBasicParsing).Content | ConvertFrom-Json

Write-Output "Groupe créé avec ID: $($newGroup.id)"

# Supprimer le groupe
Invoke-WebRequest -Uri "http://localhost:8089/api/groups/$($newGroup.id)" -Method DELETE -UseBasicParsing

Write-Output "Groupe supprimé avec succès!"
```

Si ce test fonctionne, alors le backend est OK et le problème vient du frontend.

## Erreurs Courantes

### Erreur 500: Internal Server Error
**Cause**: Le backend n'a pas été redémarré avec les nouvelles modifications
**Solution**: Redémarrez le backend (voir Étape 1)

### Erreur 404: Not Found
**Cause**: Le backend n'est pas démarré ou tourne sur un autre port
**Solution**: Vérifiez que le backend tourne sur http://localhost:8089

### Erreur de Contrainte de Clé Étrangère
**Cause**: Ancien code sans les annotations @Modifying
**Solution**: Assurez-vous que le backend a été redémarré

### Pas de Réponse du Serveur
**Cause**: Le backend n'est pas démarré
**Solution**: Démarrez le backend depuis votre IDE

## Checklist de Dépannage

- [ ] Le backend Spring Boot est démarré
- [ ] Le backend tourne sur le port 8089
- [ ] Le frontend Angular tourne sur le port 4200
- [ ] La base de données MySQL/MariaDB est accessible
- [ ] Les fichiers Java ont été modifiés (vérifiez les timestamps)
- [ ] Le backend a été redémarré APRÈS les modifications
- [ ] Aucune erreur dans les logs du backend
- [ ] Aucune erreur dans la console du navigateur

## Besoin d'Aide?

Si le problème persiste après avoir suivi ce guide:

1. **Vérifiez les logs du backend** - Copiez l'erreur exacte
2. **Vérifiez la console du navigateur** (F12) - Notez les erreurs HTTP
3. **Testez l'API directement** avec le script PowerShell ci-dessus
4. **Vérifiez que tous les fichiers ont été sauvegardés** dans votre IDE

## Résumé

Le problème principal est que **le backend doit être redémarré** pour appliquer les corrections.

Une fois redémarré, la suppression de groupes fonctionnera parfaitement avec:
- Suppression en cascade des posts, événements et membres
- Messages de confirmation clairs
- Gestion d'erreurs appropriée
- Logs détaillés pour le débogage

✅ **Après le redémarrage du backend, tout devrait fonctionner!**
