# Comments & Reactions Feature

## Vue d'ensemble

Cette fonctionnalité ajoute un système complet de commentaires et de réactions aux posts, similaire à Facebook, avec des emojis pour exprimer différentes émotions.

## Fonctionnalités implémentées

### 🎭 Système de Réactions
- **6 types de réactions** : Like (👍), Love (❤️), Happy (😊), Sad (😢), Angry (😠), Wow (😮)
- **Interface intuitive** : Bouton principal "Like" + sélecteur d'emojis
- **Compteurs en temps réel** : Affichage du nombre de réactions par type
- **Toggle des réactions** : Cliquer sur la même réaction la supprime
- **Réactions multiples** : Un utilisateur peut changer de réaction

### 💬 Système de Commentaires
- **Ajout de commentaires** : Interface simple avec textarea
- **Affichage hiérarchique** : Liste des commentaires avec auteur et timestamp
- **Édition/Suppression** : Les utilisateurs peuvent modifier leurs propres commentaires
- **Compteur de commentaires** : Nombre total affiché
- **Interface pliable** : Les commentaires peuvent être masqués/affichés

## Architecture Backend

### Nouvelles Entités
```java
// Comment.java
- id: Long
- post: Post (ManyToOne)
- authorId: Long
- content: String
- createdAt: LocalDateTime

// Reaction.java
- id: Long
- post: Post (ManyToOne)
- authorId: Long
- type: ReactionType (ENUM)
- createdAt: LocalDateTime

// ReactionType.java (ENUM)
- LIKE, LOVE, HAPPY, SAD, ANGRY, WOW
```

### Nouveaux Contrôleurs
- **CommentController** : CRUD pour les commentaires
- **ReactionController** : Gestion des réactions
- **PostController** : Enrichi avec données de commentaires/réactions

### Nouveaux Services
- **CommentService** : Logique métier des commentaires
- **ReactionService** : Logique métier des réactions avec toggle

## Architecture Frontend

### Nouveaux Composants
```typescript
// PostReactionsComponent
- Affichage des réactions avec emojis
- Sélecteur de réactions
- Compteurs en temps réel

// PostCommentsComponent
- Liste des commentaires
- Formulaire d'ajout
- Édition/suppression
```

### Nouveaux Services
```typescript
// CommentService
- addComment(), getCommentsByPost()
- updateComment(), deleteComment()

// ReactionService
- addOrUpdateReaction(), getReactionCounts()
- getUserReaction(), removeReaction()
```

## APIs Disponibles

### Comments API
```
POST   /api/comments                    - Ajouter un commentaire
GET    /api/comments/post/{postId}      - Récupérer les commentaires d'un post
GET    /api/comments/post/{postId}/count - Compter les commentaires
PUT    /api/comments/{commentId}        - Modifier un commentaire
DELETE /api/comments/{commentId}        - Supprimer un commentaire
```

### Reactions API
```
POST   /api/reactions                           - Ajouter/modifier une réaction
GET    /api/reactions/post/{postId}/counts      - Compter les réactions par type
GET    /api/reactions/post/{postId}/user/{userId} - Réaction de l'utilisateur
DELETE /api/reactions/post/{postId}/user/{userId} - Supprimer une réaction
```

### Posts API (Enrichie)
```
GET    /api/posts/group/{groupId}/user/{userId} - Posts avec réactions utilisateur
```

## Utilisation

### Dans le Template
```html
<!-- Intégration dans un post -->
<div class="post-card">
  <div class="post-content">
    <!-- Contenu du post -->
  </div>
  
  <div class="post-interactions">
    <!-- Composant Réactions -->
    <app-post-reactions 
      [postId]="post.id"
      [currentUserId]="currentUser.id"
      (reactionChanged)="onReactionChanged()">
    </app-post-reactions>
    
    <!-- Composant Commentaires -->
    <app-post-comments 
      [postId]="post.id"
      [currentUserId]="currentUser.id"
      [showComments]="false"
      (commentAdded)="onCommentAdded()">
    </app-post-comments>
  </div>
</div>
```

### Configuration
1. **Backend** : Les nouvelles entités sont automatiquement créées par JPA
2. **Frontend** : Les composants sont déclarés dans `app.module.ts`
3. **Styles** : CSS responsive inclus pour mobile et desktop

## Fonctionnalités Avancées

### Réactions
- **Affichage intelligent** : Top 3 réactions les plus populaires
- **Animation hover** : Effet de survol sur les emojis
- **Responsive** : Interface adaptée mobile/desktop
- **Validation** : Une seule réaction par utilisateur par post

### Commentaires
- **Timestamps relatifs** : "2h ago", "Just now"
- **Édition en place** : Interface d'édition intégrée
- **Validation** : Commentaires non vides requis
- **Gestion d'erreurs** : Feedback utilisateur en cas d'erreur

## Améliorations Futures

### Possibles Extensions
1. **Réactions sur commentaires** : Étendre le système aux commentaires
2. **Notifications** : Alertes pour nouvelles réactions/commentaires
3. **Mentions** : @username dans les commentaires
4. **Réponses** : Commentaires imbriqués (threads)
5. **Modération** : Signalement de contenu inapproprié
6. **Analytics** : Statistiques d'engagement détaillées

### Optimisations
1. **Pagination** : Pour les posts avec beaucoup de commentaires
2. **Cache** : Mise en cache des compteurs de réactions
3. **WebSocket** : Mises à jour en temps réel
4. **Lazy Loading** : Chargement différé des commentaires

## Sécurité

### Validations Implémentées
- **Autorisation** : Seul l'auteur peut modifier/supprimer ses commentaires
- **Validation côté serveur** : Contenu non vide, IDs valides
- **Sanitisation** : Protection contre XSS (à implémenter)
- **Rate limiting** : À implémenter pour éviter le spam

## Tests

### Tests Recommandés
1. **Unit Tests** : Services et composants
2. **Integration Tests** : APIs et base de données
3. **E2E Tests** : Parcours utilisateur complet
4. **Performance Tests** : Charge avec nombreuses réactions/commentaires

Cette implémentation fournit une base solide pour un système d'engagement social moderne et extensible.