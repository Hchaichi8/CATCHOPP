import { Injectable } from '@angular/core';

export type NotificationType = 'event' | 'club' | 'group' | 'system';

export type NotificationImportance = 'low' | 'normal' | 'high';

export interface NotificationItem {
  id: number;
  type: NotificationType;
  title: string;
  message: string;
  createdAt: Date;
  read: boolean;
  importance: NotificationImportance;
  relatedRoute?: string;
}

export interface NotificationGroup {
  type: NotificationType;
  label: string;
  items: NotificationItem[];
}

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  private items: NotificationItem[] = [
    {
      id: 1,
      type: 'event',
      title: 'Meetup Frontend Remote',
      message: 'Starts in 2 hours. Get your questions ready.',
      createdAt: new Date(),
      read: false,
      importance: 'high',
      relatedRoute: '/groups/1'
    },
    {
      id: 2,
      type: 'club',
      title: 'New discussion in Frontend Club',
      message: 'A member started a thread about Angular Signals.',
      createdAt: new Date(),
      read: false,
      importance: 'normal',
      relatedRoute: '/Club/1'
    },
    {
      id: 3,
      type: 'system',
      title: 'Welcome to communities',
      message: 'Join groups and clubs to grow your network.',
      createdAt: new Date(),
      read: true,
      importance: 'low'
    }
  ];

  get all(): NotificationItem[] {
    return this.items;
  }

  get unreadCount(): number {
    return this.items.filter(i => !i.read).length;
  }

  getGroups(): NotificationGroup[] {
    const map: { [k in NotificationType]: NotificationGroup } = {
      event: { type: 'event', label: 'Events', items: [] },
      club: { type: 'club', label: 'Clubs', items: [] },
      group: { type: 'group', label: 'Groups', items: [] },
      system: { type: 'system', label: 'System', items: [] }
    };

    for (const item of this.items) {
      map[item.type].items.push(item);
    }

    return Object.values(map).filter(g => g.items.length > 0);
  }

  addNotification(partial: {
    type: NotificationType;
    title: string;
    message: string;
    importance?: NotificationImportance;
    relatedRoute?: string;
  }): void {
    const notification: NotificationItem = {
      id: Date.now(),
      type: partial.type,
      title: partial.title,
      message: partial.message,
      createdAt: new Date(),
      read: false,
      importance: partial.importance ?? 'normal',
      relatedRoute: partial.relatedRoute
    };
    this.items = [notification, ...this.items];
  }

  markAsRead(id: number): void {
    this.items = this.items.map(i =>
      i.id === id ? { ...i, read: true } : i
    );
  }

  markAllAsRead(): void {
    this.items = this.items.map(i => ({ ...i, read: true }));
  }
}

