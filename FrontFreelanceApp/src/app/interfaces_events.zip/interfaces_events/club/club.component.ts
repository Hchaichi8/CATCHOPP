import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ClubService } from '../club.service';

@Component({
  selector: 'app-club',
  templateUrl: './club.component.html',
  styleUrls: ['./club.component.css']
})
export class ClubComponent implements OnInit {
  clubId!: number;
  club: any = null;
  loading = true;
  activeTab: 'about' | 'members' | 'events' | 'posts' = 'about';
  
  // Mock data
  mockClub = {
    id: 0,
    name: 'Tech Innovators Club',
    description: 'A vibrant community of developers, designers, and tech enthusiasts passionate about innovation and collaboration.',
    interests: 'Technology, Programming, Web Development, AI',
    createdAt: new Date().toISOString(),
    bannerUrl: '',
    members: [
      { id: 1, name: 'John Doe', role: 'Admin', avatar: 'https://i.pravatar.cc/150?u=john', joinedDate: '2024-01-15' },
      { id: 2, name: 'Jane Smith', role: 'Member', avatar: 'https://i.pravatar.cc/150?u=jane', joinedDate: '2024-02-20' },
      { id: 3, name: 'Mike Johnson', role: 'Moderator', avatar: 'https://i.pravatar.cc/150?u=mike', joinedDate: '2024-03-10' }
    ]
  };
  
  events = [
    { id: 1, title: 'Tech Meetup 2026', date: new Date('2026-03-15'), location: 'Conference Hall A' },
    { id: 2, title: 'Coding Workshop', date: new Date('2026-03-25'), location: 'Room 101' }
  ];
  
  posts = [
    { id: 1, author: 'John Doe', content: 'Welcome everyone to our tech community!', date: new Date('2026-02-18'), likes: 24 },
    { id: 2, author: 'Jane Smith', content: 'Excited for the upcoming workshop!', date: new Date('2026-02-19'), likes: 15 }
  ];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private clubService: ClubService
  ) {}

  ngOnInit(): void {
    this.clubId = Number(this.route.snapshot.paramMap.get('id'));
    this.loadClub();
  }

  loadClub(): void {
    this.loading = true;
    this.clubService.getClubById(this.clubId).subscribe({
      next: (data) => {
        this.club = data;
        this.loading = false;
      },
      error: () => {
        // Use mock data on error
        this.club = { ...this.mockClub, id: this.clubId };
        this.loading = false;
      }
    });
  }

  setTab(tab: 'about' | 'members' | 'events' | 'posts'): void {
    this.activeTab = tab;
  }

  goBack(): void {
    this.router.navigate(['/groups']);
  }

  shareClub(): void {
    alert('Share functionality - Coming soon!');
  }

  inviteFriends(): void {
    alert('Invite friends - Coming soon!');
  }

  leaveClub(): void {
    if (confirm('Are you sure you want to leave this club?')) {
      this.router.navigate(['/groups']);
    }
  }

  getMemberInitials(name: string): string {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  }

  getInterests(): string[] {
    if (!this.club?.interests) return [];
    return this.club.interests.split(',').map((i: string) => i.trim());
  }
}
