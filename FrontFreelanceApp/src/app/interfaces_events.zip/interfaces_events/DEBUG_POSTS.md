# Debug des Posts - Guide de Test

## Tests à Effectuer

### 1. Tester les APIs Backend Directement

#### Vérifier tous les posts
```bash
curl http://localhost:8089/api/posts/debug/all
```

#### Vérifier les posts d'un groupe spécifique
```bash
curl http://localhost:8089/api/posts/debug/group/1
```

#### Créer un post de test
```bash
curl -X POST http://localhost:8089/api/posts \
  -H "Content-Type: application/json" \
  -d '{
    "group": {"id": 1},
    "authorId": 1,
    "content": "Test post from curl",
    "isAnnouncement": false
  }'
```

#### Vérifier les posts enrichis
```bash
curl http://localhost:8089/api/posts/group/1/user/1
```

### 2. Vérifier la Base de Données

Dans phpMyAdmin, vérifiez :
- Table `posts` : Vérifiez que `group_id` est bien renseigné
- Table `groups` : Vérifiez qu'il existe un groupe avec l'ID utilisé

### 3. Logs à Vérifier

#### Backend (Console Spring Boot)
Recherchez les logs :
```
Creating post: [content] for group: [groupId]
Post saved with ID: [id]
Looking for posts in group: [groupId]
Found [count] posts for group [groupId]
```

#### Frontend (Console Navigateur)
Ouvrez les DevTools et vérifiez :
- Erreurs dans la console
- Onglet Network pour voir les requêtes HTTP
- Réponses des APIs

## Solutions Possibles

### Si les posts n'ont pas de group_id
Le problème vient de la création. Vérifiez que l'objet `group` est bien envoyé.

### Si l'API ne retourne pas les posts
Le problème vient de la requête JPA. Utilisez la méthode alternative dans le repository.

### Si le frontend ne charge pas les posts
Le problème vient de la méthode `loadGroupPosts()` ou de la gestion des erreurs.